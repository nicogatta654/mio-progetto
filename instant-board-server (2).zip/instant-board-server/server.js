'use strict';

require('dotenv').config();
const express = require('express');
const multer = require('multer');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'sounds.json');
const IS_PRODUCTION = process.env.NODE_ENV === 'production';
const APP_PASSWORD = process.env.APP_PASSWORD || (IS_PRODUCTION ? '' : 'instants-local-2026');
const MAX_FILE_BYTES = 100 * 1024 * 1024;
const MAX_FILES_PER_UPLOAD = 30;
const AUDIO_EXTENSIONS = new Set(['.mp3', '.wav', '.m4a', '.aac', '.ogg', '.opus', '.flac', '.webm', '.aif', '.aiff', '.mp4']);
const sessions = new Set();

if (IS_PRODUCTION && !APP_PASSWORD) {
  console.error('ERRORE: in produzione devi impostare la variabile APP_PASSWORD con una password privata.');
  process.exit(1);
}

fs.mkdirSync(UPLOAD_DIR, { recursive: true });
let sounds = [];
let saveQueue = Promise.resolve();

function safeEqual(a, b) {
  const left = Buffer.from(String(a || ''), 'utf8');
  const right = Buffer.from(String(b || ''), 'utf8');
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

function cookieValue(req, name) {
  const header = req.headers.cookie || '';
  for (const item of header.split(';')) {
    const index = item.indexOf('=');
    if (index < 0) continue;
    if (item.slice(0, index).trim() === name) return decodeURIComponent(item.slice(index + 1).trim());
  }
  return '';
}

function requestToken(req) {
  return String(req.get('x-app-token') || cookieValue(req, 'instants_session') || '');
}

function hasValidSession(req) {
  const token = requestToken(req);
  return token !== '' && sessions.has(token);
}

function requireSession(req, res, next) {
  if (!hasValidSession(req)) return res.status(401).json({ error: 'Accedi alla soundboard con la password del server.' });
  next();
}

function sanitizeName(value, fallback = 'Nuovo suono') {
  const result = String(value || '').replace(/[\u0000-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim();
  return (result || fallback).slice(0, 80);
}

function sanitizeCategory(value) {
  const result = String(value || 'Altro').replace(/[\u0000-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim();
  return (result || 'Altro').slice(0, 40);
}

function publicSound(sound) {
  const { storedName, ...safe } = sound;
  if (sound.type === 'file' && storedName) safe.fileUrl = `/uploads/${encodeURIComponent(storedName)}`;
  return safe;
}

function persistSounds() {
  const snapshot = JSON.stringify(sounds, null, 2);
  const operation = async () => {
    const temporaryFile = `${DB_FILE}.${process.pid}.${crypto.randomUUID()}.tmp`;
    await fsp.writeFile(temporaryFile, snapshot, 'utf8');
    await fsp.rename(temporaryFile, DB_FILE);
  };
  saveQueue = saveQueue.then(operation, operation);
  return saveQueue;
}

function validateExternalUrl(rawValue) {
  let url;
  try { url = new URL(String(rawValue || '').trim()); }
  catch { throw new Error('Il link non sembra un URL valido.'); }
  if (url.protocol !== 'https:') throw new Error('Per sicurezza, usa un link che inizi con https://.');
  const hostname = url.hostname.toLowerCase();
  const isYoutube = ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be', 'youtube-nocookie.com', 'www.youtube-nocookie.com'].includes(hostname);
  const isTikTok = hostname === 'tiktok.com' || hostname.endsWith('.tiktok.com');
  if (!isYoutube && !isTikTok) throw new Error('Incolla un link di YouTube o TikTok.');
  return { url, isYoutube, isTikTok };
}

function extractYouTubeId(url) {
  const host = url.hostname.toLowerCase();
  let candidate = '';
  if (host === 'youtu.be') candidate = url.pathname.split('/').filter(Boolean)[0] || '';
  else if (url.pathname === '/watch') candidate = url.searchParams.get('v') || '';
  else {
    const parts = url.pathname.split('/').filter(Boolean);
    const marker = parts.findIndex(part => ['shorts', 'embed', 'live', 'v'].includes(part));
    if (marker >= 0) candidate = parts[marker + 1] || '';
  }
  return /^[A-Za-z0-9_-]{11}$/.test(candidate) ? candidate : '';
}

function extractTikTokId(url) {
  const player = url.pathname.match(/\/player\/v1\/(\d+)/);
  if (player) return player[1];
  const video = url.pathname.match(/\/video\/(\d+)/);
  if (video) return video[1];
  return '';
}

async function resolveShortTikTok(url) {
  let current = url;
  for (let i = 0; i < 6; i += 1) {
    const id = extractTikTokId(current);
    if (id) return { url: current, id };
    const host = current.hostname.toLowerCase();
    if (!(host === 'tiktok.com' || host.endsWith('.tiktok.com'))) throw new Error('Il link TikTok deve puntare al sito ufficiale.');
    let response;
    try {
      response = await fetch(current, {
        method: 'GET', redirect: 'manual',
        headers: { 'user-agent': 'Mozilla/5.0 (compatible; INSTANTS/1.0)' },
        signal: AbortSignal.timeout(6000)
      });
    } catch {
      throw new Error('Non riesco a risolvere questo link TikTok abbreviato. Incolla il link completo del video, se disponibile.');
    }
    const location = response.headers.get('location');
    if (![301, 302, 303, 307, 308].includes(response.status) || !location) break;
    const nextUrl = new URL(location, current);
    if (nextUrl.protocol !== 'https:' || !(nextUrl.hostname === 'tiktok.com' || nextUrl.hostname.endsWith('.tiktok.com'))) {
      throw new Error('Il link breve non reindirizza a una pagina TikTok valida.');
    }
    current = nextUrl;
  }
  const id = extractTikTokId(current);
  if (id) return { url: current, id };
  throw new Error('Non trovo l’ID del video. Prova a copiare il link completo del post TikTok (quello con /video/ e il numero).');
}

function secondsValue(value, fallback) {
  const number = Number(value ?? fallback);
  if (!Number.isFinite(number) || number < 0) throw new Error('Gli orari devono essere numeri di secondi validi.');
  return Math.floor(number);
}

app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

app.post('/api/login', (req, res) => {
  const password = String(req.body?.password || '');
  if (!APP_PASSWORD || !safeEqual(password, APP_PASSWORD)) {
    return res.status(401).json({ error: 'Password non corretta. Riprova.' });
  }
  const token = crypto.randomBytes(32).toString('hex');
  sessions.add(token);
  const secure = IS_PRODUCTION ? '; Secure' : '';
  res.setHeader('Set-Cookie', `instants_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000${secure}`);
  return res.json({ token });
});

// Authentication also applies to uploaded audio. Native browser audio requests carry the login cookie.
app.use('/uploads', requireSession, express.static(UPLOAD_DIR, { index: false, fallthrough: false, maxAge: '1h' }));
app.use('/api', (req, res, next) => {
  if (req.path === '/login' || req.path === '/health') return next();
  return requireSession(req, res, next);
});

app.get('/api/sounds', (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json({ sounds: sounds.map(publicSound) });
});

const storage = multer.diskStorage({
  destination: (_req, _file, callback) => callback(null, UPLOAD_DIR),
  filename: (_req, file, callback) => {
    const extension = path.extname(file.originalname || '').toLowerCase();
    callback(null, `${crypto.randomUUID()}${extension}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: MAX_FILE_BYTES, files: MAX_FILES_PER_UPLOAD, fieldSize: 1024 * 64 },
  fileFilter: (_req, file, callback) => {
    const extension = path.extname(file.originalname || '').toLowerCase();
    const isAudio = (String(file.mimetype || '').startsWith('audio/') || ['video/webm', 'video/mp4', 'application/ogg'].includes(file.mimetype)) && AUDIO_EXTENSIONS.has(extension);
    callback(isAudio ? null : new Error(`Formato non supportato per “${file.originalname}”. Usa MP3, WAV, M4A, AAC, OGG, OPUS o FLAC.`), isAudio);
  }
});

app.post('/api/upload', upload.array('files', MAX_FILES_PER_UPLOAD), async (req, res, next) => {
  try {
    const files = req.files || [];
    if (!files.length) return res.status(400).json({ error: 'Seleziona almeno un file audio.' });
    const category = sanitizeCategory(req.body.category);
    const created = files.map((file, index) => ({
      id: crypto.randomUUID(),
      name: sanitizeName(path.basename(file.originalname, path.extname(file.originalname)), 'Nuovo suono'),
      category,
      type: 'file',
      storedName: file.filename,
      mimeType: file.mimetype || 'application/octet-stream',
      size: file.size,
      favorite: false,
      createdAt: Date.now() + index
    }));
    sounds.push(...created);
    await persistSounds();
    res.status(201).json({ sounds: created.map(publicSound) });
  } catch (error) { next(error); }
});

app.post('/api/links', async (req, res, next) => {
  try {
    const { url, isYoutube, isTikTok } = validateExternalUrl(req.body?.url);
    const startSeconds = secondsValue(req.body?.startSeconds, 0);
    const endSeconds = secondsValue(req.body?.endSeconds, 8);
    if (endSeconds <= startSeconds) return res.status(400).json({ error: 'L’orario finale deve essere maggiore di quello iniziale.' });
    if (endSeconds - startSeconds > 600) return res.status(400).json({ error: 'Per una clip, scegli al massimo 10 minuti.' });
    if (endSeconds > 86400) return res.status(400).json({ error: 'L’orario finale è troppo grande.' });

    let type, videoId, resolvedUrl = url.href;
    if (isYoutube) {
      type = 'youtube';
      videoId = extractYouTubeId(url);
      if (!videoId) return res.status(400).json({ error: 'Non trovo l’ID del video YouTube. Incolla un link video, Shorts o youtu.be valido.' });
    } else if (isTikTok) {
      type = 'tiktok';
      const resolved = await resolveShortTikTok(url);
      videoId = resolved.id;
      resolvedUrl = resolved.url.href;
    }

    const category = sanitizeCategory(req.body?.category);
    const providerName = type === 'youtube' ? 'YouTube' : 'TikTok';
    const sound = {
      id: crypto.randomUUID(),
      name: sanitizeName(req.body?.name, `${providerName} ${Math.floor(startSeconds / 60)}:${String(startSeconds % 60).padStart(2, '0')}`),
      category, type, url: resolvedUrl, videoId, startSeconds, endSeconds,
      favorite: false, size: 0, createdAt: Date.now()
    };
    sounds.push(sound);
    await persistSounds();
    res.status(201).json({ sound: publicSound(sound) });
  } catch (error) { next(error); }
});

app.patch('/api/sounds/:id', async (req, res, next) => {
  try {
    const sound = sounds.find(item => item.id === req.params.id);
    if (!sound) return res.status(404).json({ error: 'Suono non trovato.' });
    if (Object.hasOwn(req.body || {}, 'name')) sound.name = sanitizeName(req.body.name, sound.name);
    if (Object.hasOwn(req.body || {}, 'category')) sound.category = sanitizeCategory(req.body.category);
    if (Object.hasOwn(req.body || {}, 'favorite')) {
      if (typeof req.body.favorite !== 'boolean') return res.status(400).json({ error: 'Valore preferito non valido.' });
      sound.favorite = req.body.favorite;
    }
    await persistSounds();
    res.json({ sound: publicSound(sound) });
  } catch (error) { next(error); }
});

app.delete('/api/sounds/:id', async (req, res, next) => {
  try {
    const index = sounds.findIndex(item => item.id === req.params.id);
    if (index < 0) return res.status(404).json({ error: 'Suono non trovato.' });
    const [sound] = sounds.splice(index, 1);
    await persistSounds();
    if (sound.storedName) {
      const filePath = path.join(UPLOAD_DIR, path.basename(sound.storedName));
      await fsp.unlink(filePath).catch(error => { if (error.code !== 'ENOENT') throw error; });
    }
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.use(express.static(PUBLIC_DIR, { extensions: ['html'], index: 'index.html', maxAge: IS_PRODUCTION ? '1h' : 0 }));

app.use((error, _req, res, _next) => {
  console.error(error);
  if (res.headersSent) return;
  if (error instanceof multer.MulterError) {
    const message = error.code === 'LIMIT_FILE_SIZE'
      ? 'Un file supera il limite di 100 MB.'
      : error.code === 'LIMIT_FILE_COUNT' || error.code === 'LIMIT_UNEXPECTED_FILE'
        ? `Puoi caricare fino a ${MAX_FILES_PER_UPLOAD} file alla volta.`
        : 'Caricamento non riuscito. Controlla i file e riprova.';
    return res.status(400).json({ error: message });
  }
  if (error.status === 404 && String(error.path || '').includes('/uploads/')) return res.status(404).json({ error: 'File non trovato.' });
  const message = IS_PRODUCTION ? 'Si è verificato un errore sul server. Riprova.' : (error.message || 'Errore interno del server.');
  res.status(400).json({ error: message });
});

async function start() {
  try {
    const raw = await fsp.readFile(DB_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    sounds = Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    if (error.code !== 'ENOENT') {
      console.error('Database non leggibile. Creo una raccolta vuota:', error.message);
    }
    sounds = [];
    await persistSounds();
  }
  app.listen(PORT, HOST, () => {
    console.log(`\nINSTANTS — Sound Station attiva su http://localhost:${PORT}`);
    console.log(`Cartella dei file: ${UPLOAD_DIR}`);
    if (!process.env.APP_PASSWORD && !IS_PRODUCTION) {
      console.log('Password iniziale locale: instants-local-2026 (cambiala nel file .env prima di pubblicare il sito).');
    }
    console.log('Per aprirla da un telefono sulla stessa Wi-Fi, usa l’indirizzo IP locale di questo computer.\n');
  });
}

start().catch(error => { console.error('Avvio server non riuscito:', error); process.exit(1); });
