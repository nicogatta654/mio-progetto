(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const els = {
    addButtons: [$('#addSoundsBtn'), $('#addSoundsBtnSecondary'), $('#emptyImportBtn')],
    audioFiles: $('#audioFiles'), stopAllBtn: $('#stopAllBtn'), soundSearch: $('#soundSearch'),
    categoryFilter: $('#categoryFilter'), importCategory: $('#importCategory'), sourceCategory: $('#sourceCategory'),
    volumeSlider: $('#volumeSlider'), volumeValue: $('#volumeValue'), emptyState: $('#emptyState'),
    noResults: $('#noResults'), soundGrid: $('#soundGrid'), dropZone: $('#dropZone'), dropHint: $('#dropHint'),
    soundCount: $('#soundCount'), footerSoundCount: $('#footerSoundCount'), mineView: $('#mineView'),
    myinstantsView: $('#myinstantsView'), viewTitle: $('#viewTitle'), viewSubhead: $('#viewSubhead'),
    toast: $('#toast'), myinstantsSearchForm: $('#myinstantsSearchForm'), myinstantsSearch: $('#myinstantsSearch'),
    serverStatus: $('#serverStatus'), sourceForm: $('#sourceForm'), sourceUrl: $('#sourceUrl'),
    sourceName: $('#sourceName'), clipStart: $('#clipStart'), clipEnd: $('#clipEnd'), saveSourceBtn: $('#saveSourceBtn'),
    sourceFormNote: $('#sourceFormNote'), sourcePlayer: $('#sourcePlayer'), sourcePlayerTitle: $('#sourcePlayerTitle'),
    sourcePlayerHelp: $('#sourcePlayerHelp'), closeSourcePlayer: $('#closeSourcePlayer'), ytPlayerHost: $('#ytPlayerHost'),
    tiktokPlayer: $('#tiktokPlayer'), loginOverlay: $('#loginOverlay'), loginForm: $('#loginForm'),
    serverPassword: $('#serverPassword'), loginError: $('#loginError'), loginBtn: $('#loginBtn')
  };

  let allSounds = [];
  let playingAudios = new Map();
  let toastTimer;
  let currentView = 'mine';
  let draggedFileOver = 0;
  let volume = Number(localStorage.getItem('instants-volume') || 85) / 100;
  let authToken = localStorage.getItem('instants-server-token') || '';
  let ytPlayer = null;
  let ytPlayerReady = false;
  let ytApiReady = false;
  let pendingYoutube = null;
  let activeClip = null;
  let youtubeCheckTimer = null;
  let fallbackClipTimer = null;
  let tiktokReady = false;

  els.volumeSlider.value = String(Math.round(volume * 100));
  els.volumeValue.value = `${Math.round(volume * 100)}%`;
  els.volumeValue.textContent = `${Math.round(volume * 100)}%`;

  function notify(message, duration = 3000) {
    clearTimeout(toastTimer);
    els.toast.textContent = message;
    els.toast.classList.add('show');
    toastTimer = setTimeout(() => els.toast.classList.remove('show'), duration);
  }

  function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  }

  function prettySize(bytes) {
    if (!Number.isFinite(Number(bytes)) || Number(bytes) < 1) return 'CLIP ONLINE';
    if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  function cleanName(filename) {
    return String(filename || '').replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim() || 'Nuovo suono';
  }

  function timeLabel(seconds) {
    const total = Math.max(0, Math.floor(Number(seconds) || 0));
    const min = Math.floor(total / 60);
    const sec = total % 60;
    return `${min}:${String(sec).padStart(2, '0')}`;
  }

  function parseClipTime(value) {
    const text = String(value || '').trim();
    if (!text) throw new Error('Inserisci un orario iniziale e finale.');
    if (/^\d+$/.test(text)) return Number(text);
    const match = text.match(/^(\d+):([0-5]\d)$/);
    if (!match) throw new Error('Usa il formato minuti:secondi, ad esempio 1:25.');
    return Number(match[1]) * 60 + Number(match[2]);
  }

  function showLogin(message = '') {
    els.loginOverlay.hidden = false;
    els.loginError.hidden = !message;
    els.loginError.textContent = message;
    els.serverPassword.focus();
  }

  function hideLogin() {
    els.loginOverlay.hidden = true;
    els.loginError.hidden = true;
  }

  async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    if (authToken) headers.set('x-app-token', authToken);
    if (options.body && !(options.body instanceof FormData) && !headers.has('content-type')) {
      headers.set('content-type', 'application/json');
    }
    const response = await fetch(path, { ...options, headers });
    if (response.status === 401 && path !== '/api/login') {
      authToken = '';
      localStorage.removeItem('instants-server-token');
      showLogin('La sessione è terminata. Inserisci di nuovo la password.');
      throw new Error('Accedi al server per continuare.');
    }
    const contentType = response.headers.get('content-type') || '';
    const payload = contentType.includes('application/json') ? await response.json() : null;
    if (!response.ok) throw new Error(payload?.error || `Errore server (${response.status}).`);
    return payload;
  }

  async function connectAndLoad() {
    try {
      const health = await fetch('/api/health', { cache: 'no-store' });
      if (!health.ok) throw new Error('Server non raggiungibile');
      const response = await api('/api/sounds', { cache: 'no-store' });
      allSounds = Array.isArray(response.sounds) ? response.sounds : [];
      els.serverStatus.innerHTML = '<i></i> SERVER CONNESSO';
      els.serverStatus.classList.add('is-online');
      hideLogin();
      refreshCategoryOptions();
      renderSounds();
    } catch (error) {
      if (error.message.includes('password') || error.message.includes('Accedi')) return;
      els.serverStatus.innerHTML = '<i></i> SERVER NON DISPONIBILE';
      els.serverStatus.classList.remove('is-online');
      if (!authToken || error.message.includes('401')) showLogin();
      else notify('Non riesco a raggiungere il server. Controlla la connessione e ricarica la pagina.', 5000);
    }
  }

  async function postLogin(password) {
    const response = await fetch('/api/login', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ password })
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || 'Password non corretta.');
    authToken = payload.token;
    localStorage.setItem('instants-server-token', authToken);
    await connectAndLoad();
  }

  function refreshCategoryOptions() {
    const categories = [...new Set(allSounds.map(sound => sound.category || 'Altro'))]
      .sort((a, b) => a.localeCompare(b, 'it'));
    const selectedFilter = els.categoryFilter.value || 'all';
    els.categoryFilter.innerHTML = '<option value="all">Tutte le categorie</option>' +
      categories.map(category => `<option value="${escapeHTML(category)}">${escapeHTML(category)}</option>`).join('');
    if (categories.includes(selectedFilter)) els.categoryFilter.value = selectedFilter;

    const builtins = ['Meme', 'Reaction', 'Musica', 'Effetti', 'Altro'];
    const options = [...new Set([...builtins, ...categories])].sort((a, b) => {
      const ai = builtins.indexOf(a), bi = builtins.indexOf(b);
      if (ai >= 0 && bi >= 0) return ai - bi;
      if (ai >= 0) return -1;
      if (bi >= 0) return 1;
      return a.localeCompare(b, 'it');
    });
    for (const select of [els.importCategory, els.sourceCategory]) {
      const previous = select.value || 'Meme';
      select.innerHTML = options.map(category => `<option value="${escapeHTML(category)}">${escapeHTML(category)}</option>`).join('') +
        '<option value="new">＋ Nuova categoria…</option>';
      select.value = options.includes(previous) ? previous : 'Meme';
    }
  }

  function filteredSounds() {
    const query = els.soundSearch.value.trim().toLocaleLowerCase('it');
    const category = els.categoryFilter.value;
    return allSounds.filter(sound => {
      const matchesName = !query || `${sound.name} ${sound.category || ''} ${sound.type || ''}`.toLocaleLowerCase('it').includes(query);
      const matchesCategory = category === 'all' || (sound.category || 'Altro') === category;
      return matchesName && matchesCategory;
    });
  }

  function soundKindLabel(sound) {
    if (sound.type === 'youtube') return 'YOUTUBE CLIP';
    if (sound.type === 'tiktok') return 'TIKTOK CLIP';
    return prettySize(sound.size);
  }

  function renderSounds() {
    const filtered = filteredSounds();
    const total = allSounds.length;
    els.soundCount.textContent = String(total).padStart(2, '0');
    els.footerSoundCount.textContent = String(total);
    els.emptyState.hidden = total > 0;
    els.noResults.hidden = total === 0 || filtered.length > 0;
    els.soundGrid.hidden = total === 0 || filtered.length === 0;
    els.soundGrid.innerHTML = filtered.map((sound, index) => {
      const id = escapeHTML(sound.id);
      const name = escapeHTML(sound.name);
      const category = escapeHTML(sound.category || 'Altro');
      const playing = playingAudios.has(sound.id) || activeClip?.id === sound.id;
      const sourceLabel = sound.type === 'youtube' || sound.type === 'tiktok'
        ? `${timeLabel(sound.startSeconds)}–${timeLabel(sound.endSeconds)}`
        : prettySize(sound.size);
      return `<article class="sound-card${playing ? ' is-playing' : ''}" data-id="${id}">
        <div class="sound-card-actions">
          <button type="button" data-action="favorite" data-id="${id}" class="${sound.favorite ? 'is-favorite' : ''}" aria-label="${sound.favorite ? 'Rimuovi dai preferiti' : 'Aggiungi ai preferiti'}" title="Preferito">${sound.favorite ? '★' : '☆'}</button>
          <button type="button" data-action="rename" data-id="${id}" aria-label="Rinomina ${name}" title="Rinomina">✎</button>
          <button type="button" data-action="delete" data-id="${id}" aria-label="Elimina ${name}" title="Elimina">×</button>
        </div>
        <button type="button" class="sound-main" data-action="play" data-id="${id}" aria-label="Riproduci ${name}" aria-pressed="${playing}">
          <span class="sound-card-top"><span>${String(index + 1).padStart(2, '0')} / ${sound.type === 'youtube' ? 'YT' : sound.type === 'tiktok' ? 'TT' : 'SOUND'}</span><span class="sound-play-icon">${playing ? '◼' : '▶'}</span></span>
          <span class="sound-label">${name}</span>
          <span class="sound-meta">${category} · ${escapeHTML(sourceLabel)}${sound.type === 'file' ? '' : ' · CLIP'}</span>
        </button>
      </article>`;
    }).join('');
  }

  async function reloadSounds() {
    const response = await api('/api/sounds', { cache: 'no-store' });
    allSounds = Array.isArray(response.sounds) ? response.sounds : [];
    allSounds.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    refreshCategoryOptions();
    renderSounds();
  }

  async function chooseCategory(select) {
    let category = select.value;
    if (category === 'new') {
      category = window.prompt('Nome della nuova categoria:', 'I miei audio');
      if (!category || !category.trim()) {
        select.value = 'Meme';
        return null;
      }
      category = category.trim().slice(0, 40);
      if (![...select.options].some(option => option.value === category)) {
        for (const dropdown of [els.importCategory, els.sourceCategory]) {
          const option = document.createElement('option');
          option.value = category;
          option.textContent = category;
          const newOption = dropdown.querySelector('option[value="new"]');
          dropdown.insertBefore(option, newOption);
        }
      }
      els.importCategory.value = category;
      els.sourceCategory.value = category;
    }
    return category;
  }

  function chooseAudioFiles() { els.audioFiles.click(); }

  async function importFiles(fileList) {
    const files = [...fileList].filter(file => file && (file.type.startsWith('audio/') || /\.(mp3|wav|m4a|aac|ogg|opus|flac|webm|aiff?)$/i.test(file.name)));
    if (!files.length) { notify('Non ho trovato file audio. Prova con MP3, WAV o M4A.'); return; }
    const category = await chooseCategory(els.importCategory);
    if (!category) return;
    const data = new FormData();
    for (const file of files) data.append('files', file, file.name);
    data.append('category', category);
    const firstLabel = els.addButtons[0].innerHTML;
    els.addButtons.forEach(button => { button.disabled = true; });
    els.addButtons[0].innerHTML = '<span class="button-plus">…</span> CARICAMENTO';
    try {
      const result = await api('/api/upload', { method: 'POST', body: data });
      await reloadSounds();
      notify(`${result.sounds.length} ${result.sounds.length === 1 ? 'suono caricato' : 'suoni caricati'} sul server.`);
    } catch (error) {
      notify(error.message, 5000);
    } finally {
      els.audioFiles.value = '';
      els.addButtons.forEach(button => { button.disabled = false; });
      els.addButtons[0].innerHTML = firstLabel;
    }
  }

  async function saveLink(event) {
    event.preventDefault();
    let startSeconds, endSeconds;
    try {
      startSeconds = parseClipTime(els.clipStart.value);
      endSeconds = parseClipTime(els.clipEnd.value);
      if (startSeconds < 0 || endSeconds <= startSeconds) throw new Error('L’orario finale deve essere maggiore di quello iniziale.');
      if (endSeconds - startSeconds > 600) throw new Error('Per una clip, scegli al massimo 10 minuti.');
    } catch (error) { notify(error.message, 4000); return; }
    const category = await chooseCategory(els.sourceCategory);
    if (!category) return;
    els.saveSourceBtn.disabled = true;
    els.saveSourceBtn.textContent = 'SALVATAGGIO…';
    try {
      const result = await api('/api/links', {
        method: 'POST', body: JSON.stringify({
          url: els.sourceUrl.value.trim(), name: els.sourceName.value.trim(), category, startSeconds, endSeconds
        })
      });
      await reloadSounds();
      els.sourceForm.reset();
      els.clipStart.value = '0:00';
      els.clipEnd.value = '0:08';
      els.sourceCategory.value = category;
      if (result.sound?.type === 'tiktok') {
        notify('Link TikTok aggiunto! Premi il pulsante per avviare la clip selezionata.');
      } else {
        notify('Clip YouTube aggiunta alla tua soundboard!');
      }
      const note = result.sound?.type === 'tiktok'
        ? 'TikTok usa il player ufficiale. La clip partirà e si fermerà agli orari selezionati.'
        : 'YouTube usa il player ufficiale. La clip partirà e si fermerà agli orari selezionati.';
      els.sourceFormNote.textContent = note;
    } catch (error) {
      notify(error.message, 5000);
    } finally {
      els.saveSourceBtn.disabled = false;
      els.saveSourceBtn.innerHTML = '<span class="button-plus">＋</span> AGGIUNGI CLIP';
    }
  }

  function ensureYouTubeApi() {
    if (window.YT && window.YT.Player) { ytApiReady = true; return; }
    if (document.querySelector('script[data-youtube-iframe-api]')) return;
    const script = document.createElement('script');
    script.src = 'https://www.youtube.com/iframe_api';
    script.async = true;
    script.dataset.youtubeIframeApi = '1';
    document.head.appendChild(script);
  }

  function showPlayerFor(sound) {
    els.sourcePlayer.hidden = false;
    els.sourcePlayerTitle.textContent = sound.name;
    els.sourcePlayerHelp.textContent = `Riproduzione ${timeLabel(sound.startSeconds)}–${timeLabel(sound.endSeconds)}. Il player si ferma al termine della clip.`;
    els.sourcePlayer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function clearClipTimers() {
    if (youtubeCheckTimer) clearInterval(youtubeCheckTimer);
    if (fallbackClipTimer) clearTimeout(fallbackClipTimer);
    youtubeCheckTimer = null;
    fallbackClipTimer = null;
  }

  function stopClip({ reset = true, hide = false } = {}) {
    clearClipTimers();
    if (ytPlayer && ytPlayerReady) {
      try {
        ytPlayer.pauseVideo();
        if (reset && activeClip?.type === 'youtube') ytPlayer.seekTo(activeClip.startSeconds || 0, true);
      } catch (_) { /* Il player potrebbe essere in chiusura. */ }
    }
    if (els.tiktokPlayer.contentWindow) {
      try {
        sendTikTok('pause');
        if (reset && activeClip?.type === 'tiktok') sendTikTok('seekTo', activeClip.startSeconds || 0);
      } catch (_) { /* Il frame potrebbe non essere pronto. */ }
    }
    activeClip = null;
    tiktokReady = false;
    if (hide) els.sourcePlayer.hidden = true;
    renderSounds();
  }

  function finishClip() {
    clearClipTimers();
    if (activeClip?.type === 'youtube' && ytPlayer && ytPlayerReady) {
      try { ytPlayer.pauseVideo(); ytPlayer.seekTo(activeClip.startSeconds || 0, true); } catch (_) {}
    } else if (activeClip?.type === 'tiktok') {
      sendTikTok('pause');
      sendTikTok('seekTo', activeClip.startSeconds || 0);
    }
    activeClip = null;
    renderSounds();
  }

  function checkYoutubeClip() {
    if (!activeClip || activeClip.type !== 'youtube' || !ytPlayer || !ytPlayerReady) return;
    try {
      if (window.YT?.PlayerState && ytPlayer.getPlayerState() !== YT.PlayerState.PLAYING) return;
      const currentTime = ytPlayer.getCurrentTime();
      if (currentTime >= activeClip.endSeconds) finishClip();
    } catch (_) { /* Il video sta caricando i metadati. */ }
  }

  function startYoutube(sound) {
    if (!ytPlayer || !ytPlayerReady) return;
    pendingYoutube = null;
    activeClip = sound;
    tiktokReady = false;
    renderSounds();
    try {
      ytPlayer.loadVideoById({ videoId: sound.videoId, startSeconds: sound.startSeconds, endSeconds: sound.endSeconds });
      clearClipTimers();
      youtubeCheckTimer = setInterval(checkYoutubeClip, 150);
    } catch (error) {
      notify('Non riesco ad avviare questo video. Potrebbe non essere incorporabile.', 5000);
      activeClip = null;
      renderSounds();
    }
  }

  function buildYouTubePlayer(sound) {
    if (!window.YT || !window.YT.Player) {
      pendingYoutube = sound;
      ensureYouTubeApi();
      return;
    }
    ytApiReady = true;
    if (ytPlayer && ytPlayerReady) { startYoutube(sound); return; }
    pendingYoutube = sound;
    els.tiktokPlayer.hidden = true;
    els.ytPlayerHost.hidden = false;
    if (ytPlayer) return;
    ytPlayer = new YT.Player('ytPlayerHost', {
      width: '100%', height: '270', videoId: sound.videoId,
      playerVars: { autoplay: 1, playsinline: 1, rel: 0, origin: window.location.origin },
      events: {
        onReady: () => {
          ytPlayerReady = true;
          if (pendingYoutube) startYoutube(pendingYoutube);
        },
        onStateChange: event => {
          if (!window.YT || !YT.PlayerState) return;
          if (event.data === YT.PlayerState.PLAYING) {
            if (activeClip?.type === 'youtube') renderSounds();
          }
          if (event.data === YT.PlayerState.ENDED && activeClip?.type === 'youtube') finishClip();
        },
        onError: () => {
          clearClipTimers();
          notify('YouTube non permette la riproduzione di questo video incorporato.', 5000);
          activeClip = null;
          renderSounds();
        }
      }
    });
  }

  function sendTikTok(type, value) {
    const target = els.tiktokPlayer.contentWindow;
    if (!target) return;
    const message = { type, 'x-tiktok-player': true };
    if (value !== undefined) message.value = value;
    target.postMessage(message, 'https://www.tiktok.com');
  }

  function startTikTok(sound) {
    activeClip = sound;
    tiktokReady = false;
    els.ytPlayerHost.hidden = true;
    els.tiktokPlayer.hidden = false;
    const params = new URLSearchParams({ controls: '1', progress_bar: '1', timestamp: '1', autoplay: '1', music_info: '1', description: '0' });
    els.tiktokPlayer.src = `https://www.tiktok.com/player/v1/${encodeURIComponent(sound.videoId)}?${params.toString()}`;
    clearClipTimers();
    // Timeout di sicurezza se il player TikTok non invia l'evento di fine caricamento.
    fallbackClipTimer = setTimeout(() => {
      if (activeClip?.id === sound.id) {
        activeClip = null;
        clearClipTimers();
        renderSounds();
      }
    }, 30000);
    renderSounds();
  }

  function playSound(id) {
    const sound = allSounds.find(item => item.id === id);
    if (!sound) return;
    if (activeClip?.id === id) {
      stopClip({ reset: true });
      return;
    }
    stopAllSounds(false);
    if (sound.type === 'youtube') {
      showPlayerFor(sound);
      els.tiktokPlayer.hidden = true;
      els.ytPlayerHost.hidden = false;
      pendingYoutube = sound;
      buildYouTubePlayer(sound);
      return;
    }
    if (sound.type === 'tiktok') {
      showPlayerFor(sound);
      startTikTok(sound);
      return;
    }
    if (!sound.fileUrl) { notify('Questo suono non ha un file disponibile sul server.'); return; }
    const audio = new Audio(sound.fileUrl);
    audio.preload = 'auto';
    audio.volume = volume;
    playingAudios.set(sound.id, audio);
    audio.addEventListener('ended', () => {
      playingAudios.delete(sound.id);
      renderSounds();
    }, { once: true });
    audio.addEventListener('error', () => {
      playingAudios.delete(sound.id);
      renderSounds();
      notify('Non riesco a riprodurre questo file audio.', 4000);
    }, { once: true });
    audio.play().then(renderSounds).catch(error => {
      playingAudios.delete(sound.id);
      renderSounds();
      notify('Riproduzione bloccata dal browser. Tocca di nuovo il pulsante.', 4000);
      console.warn(error);
    });
  }

  function stopAllSounds(showMessage = true) {
    for (const audio of playingAudios.values()) {
      audio.pause();
      try { audio.currentTime = 0; } catch (_) {}
    }
    playingAudios.clear();
    if (activeClip) stopClip({ reset: true });
    else {
      clearClipTimers();
      if (ytPlayer && ytPlayerReady) { try { ytPlayer.pauseVideo(); } catch (_) {} }
      if (els.tiktokPlayer.contentWindow) sendTikTok('pause');
    }
    renderSounds();
    if (showMessage) notify('Tutti i suoni sono stati fermati.');
  }

  async function handleCardAction(action, id) {
    const sound = allSounds.find(item => item.id === id);
    if (!sound) return;
    if (action === 'play') { playSound(id); return; }
    if (action === 'rename') {
      const newName = window.prompt('Nuovo nome del pulsante:', sound.name);
      if (!newName || !newName.trim() || newName.trim() === sound.name) return;
      try {
        await api(`/api/sounds/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ name: newName.trim().slice(0, 80) }) });
        await reloadSounds();
      } catch (error) { notify(error.message, 4000); }
      return;
    }
    if (action === 'favorite') {
      try {
        await api(`/api/sounds/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ favorite: !sound.favorite }) });
        await reloadSounds();
      } catch (error) { notify(error.message, 4000); }
      return;
    }
    if (action === 'delete') {
      if (!window.confirm(`Vuoi eliminare “${sound.name}” dalla raccolta condivisa?`)) return;
      if (activeClip?.id === id) stopClip({ reset: true, hide: true });
      if (playingAudios.has(id)) {
        playingAudios.get(id).pause();
        playingAudios.delete(id);
      }
      try {
        await api(`/api/sounds/${encodeURIComponent(id)}`, { method: 'DELETE' });
        await reloadSounds();
        notify('Suono eliminato dalla raccolta condivisa.');
      } catch (error) { notify(error.message, 4000); }
    }
  }

  function setView(view) {
    currentView = view;
    const isMine = view === 'mine';
    els.mineView.hidden = !isMine;
    els.myinstantsView.hidden = isMine;
    $$('.view-tab').forEach(button => {
      const active = button.dataset.view === view;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    els.viewTitle.innerHTML = isMine ? 'I MIEI <span>INSTANTS</span><span class="heading-count" id="soundCount">' + String(allSounds.length).padStart(2, '0') + '</span>' : 'ESPLORA <span>MYINSTANTS</span>';
    els.viewSubhead.textContent = isMine ? 'Gli stessi pulsanti su telefono e computer.' : 'Scopri altri suoni da aggiungere alla tua raccolta.';
    els.soundCount = $('#soundCount');
    if (isMine) renderSounds();
  }

  function openMyinstantsSearch(query) {
    const trimmed = query.trim();
    const url = trimmed
      ? `https://www.myinstants.com/en/search/?name=${encodeURIComponent(trimmed)}`
      : 'https://www.myinstants.com/en/index/it/';
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  function attachEvents() {
    els.addButtons.forEach(button => button.addEventListener('click', chooseAudioFiles));
    els.audioFiles.addEventListener('change', event => importFiles(event.target.files));
    els.stopAllBtn.addEventListener('click', () => stopAllSounds());
    els.soundSearch.addEventListener('input', renderSounds);
    els.categoryFilter.addEventListener('change', renderSounds);
    els.volumeSlider.addEventListener('input', event => {
      volume = Number(event.target.value) / 100;
      localStorage.setItem('instants-volume', String(event.target.value));
      els.volumeValue.value = `${event.target.value}%`;
      els.volumeValue.textContent = `${event.target.value}%`;
      for (const audio of playingAudios.values()) audio.volume = volume;
      if (ytPlayer && ytPlayerReady) ytPlayer.setVolume(Number(event.target.value));
    });
    els.soundGrid.addEventListener('click', event => {
      const button = event.target.closest('button[data-action]');
      if (button) handleCardAction(button.dataset.action, button.dataset.id);
    });
    $$('.view-tab').forEach(button => button.addEventListener('click', () => setView(button.dataset.view)));
    els.myinstantsSearchForm.addEventListener('submit', event => {
      event.preventDefault();
      openMyinstantsSearch(els.myinstantsSearch.value);
    });
    els.sourceForm.addEventListener('submit', saveLink);
    els.closeSourcePlayer.addEventListener('click', () => stopClip({ reset: true, hide: true }));
    els.loginForm.addEventListener('submit', async event => {
      event.preventDefault();
      els.loginBtn.disabled = true;
      els.loginError.hidden = true;
      try {
        await postLogin(els.serverPassword.value);
        els.serverPassword.value = '';
      } catch (error) {
        els.loginError.textContent = error.message;
        els.loginError.hidden = false;
      } finally { els.loginBtn.disabled = false; }
    });

    els.dropZone.addEventListener('dragenter', event => {
      if (![...event.dataTransfer.types].includes('Files')) return;
      event.preventDefault(); draggedFileOver += 1; els.dropHint.hidden = false;
    });
    els.dropZone.addEventListener('dragover', event => {
      if (![...event.dataTransfer.types].includes('Files')) return;
      event.preventDefault(); event.dataTransfer.dropEffect = 'copy';
    });
    els.dropZone.addEventListener('dragleave', event => {
      if (![...event.dataTransfer.types].includes('Files')) return;
      draggedFileOver = Math.max(0, draggedFileOver - 1);
      if (!draggedFileOver) els.dropHint.hidden = true;
    });
    els.dropZone.addEventListener('drop', event => {
      if (![...event.dataTransfer.types].includes('Files')) return;
      event.preventDefault(); draggedFileOver = 0; els.dropHint.hidden = true;
      importFiles(event.dataTransfer.files);
    });
    document.addEventListener('keydown', event => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault(); els.soundSearch.focus();
      }
      if (event.key === 'Escape') {
        if (!els.sourcePlayer.hidden) stopClip({ reset: true, hide: true });
      }
    });
  }

  window.onYouTubeIframeAPIReady = () => {
    ytApiReady = true;
    if (pendingYoutube) buildYouTubePlayer(pendingYoutube);
  };

  window.addEventListener('message', event => {
    if (event.origin !== 'https://www.tiktok.com' || event.source !== els.tiktokPlayer.contentWindow) return;
    let message = event.data;
    if (typeof message === 'string') {
      try { message = JSON.parse(message); } catch (_) { return; }
    }
    if (!message || message['x-tiktok-player'] !== true) return;
    if (message.type === 'onPlayerReady' && activeClip?.type === 'tiktok') {
      tiktokReady = true;
      if (fallbackClipTimer) clearTimeout(fallbackClipTimer);
      const playingId = activeClip.id;
      fallbackClipTimer = setTimeout(() => {
        if (activeClip?.id === playingId) finishClip();
      }, Math.max(1200, (activeClip.endSeconds - activeClip.startSeconds + 1.5) * 1000));
      sendTikTok('seekTo', activeClip.startSeconds || 0);
      setTimeout(() => {
        if (activeClip?.type !== 'tiktok') return;
        sendTikTok('seekTo', activeClip.startSeconds || 0);
        sendTikTok('play');
        sendTikTok('unMute');
      }, 120);
    }
    if (message.type === 'onCurrentTime' && activeClip?.type === 'tiktok') {
      const payload = message.value || message;
      const currentTime = Number(payload.currentTime ?? payload.current_time ?? payload.time);
      if (Number.isFinite(currentTime) && currentTime >= activeClip.endSeconds) finishClip();
    }
    if (message.type === 'onStateChange' && Number(message.value) === 0 && activeClip?.type === 'tiktok') finishClip();
    if (message.type === 'onPlayerError' && activeClip?.type === 'tiktok') {
      notify('TikTok non permette la riproduzione di questo post incorporato.', 5000);
      activeClip = null; clearClipTimers(); renderSounds();
    }
  });

  async function init() {
    attachEvents();
    setView('mine');
    ensureYouTubeApi();
    await connectAndLoad();
    // Register only the shell PWA worker; the worker never caches API or uploaded audio files.
    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }

  init();
})();
