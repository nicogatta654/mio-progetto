# INSTANTS — Sound Station (server edition)

La tua soundboard con grafica rosa/blu/rossa, file audio conservati sul server e clip YouTube/TikTok salvate come pulsanti. Lo stesso URL apre la stessa raccolta su computer e telefono: non servono più esportazione e ripristino manuali.

## Cosa può fare

- Carica fino a 30 file audio per volta (massimo 100 MB ciascuno). Formati: MP3, WAV, M4A, AAC, OGG, OPUS, FLAC, AIFF e WebM/MP4 audio compatibili.
- Tiene i file caricati nella cartella dati del server e salva nomi, categorie, preferiti e link in un file JSON.
- Aggiunge link video YouTube o TikTok come pulsanti, con orario di partenza e arresto nel formato `minuti:secondi` (per esempio `1:25`). La clip può durare al massimo 10 minuti.
- Usa i player ufficiali incorporati delle piattaforme. **Non scarica né estrae il flusso audio dai video**; riproduce il segmento scelto all'interno del player ufficiale. Alcuni video possono disabilitare l'incorporamento o richiedere un accesso: in quel caso la piattaforma potrebbe non consentire la riproduzione.
- Richiede una password per usare la raccolta, anche per riprodurre i file caricati.
- Conserva dati e file dopo il riavvio, purché la cartella `data` (o `DATA_DIR`) resti persistente.

## Avvio sul tuo PC con Visual Studio Code

1. Installa Node.js **20 o più recente** dal sito ufficiale `https://nodejs.org/`.
2. Estrai lo ZIP e apri la cartella `instant-board-server` in Visual Studio Code.
3. Apri il terminale integrato (`Terminale → Nuovo terminale`) ed esegui:

   ```bash
   npm install
   ```

4. Copia `.env.example` in un nuovo file chiamato `.env`. Imposta una password tua al posto di `cambia-questa-password`, per esempio una frase che non usi altrove.
5. Avvia il server:

   ```bash
   npm start
   ```

6. Apri `http://localhost:3000` nel browser del PC e accedi con la password che hai impostato nel file `.env`.

Quando carichi un audio, viene salvato sul server e non più nel browser. Puoi spegnere e riaprire il browser senza dover importare di nuovo quei file.

## Aprire la stessa raccolta dal telefono sulla stessa Wi-Fi

Il computer deve rimanere acceso e collegato alla Wi-Fi. Trova il suo indirizzo IPv4 locale:

- **Windows:** apri il Prompt dei comandi e scrivi `ipconfig`, poi cerca “Indirizzo IPv4” dell'adattatore Wi-Fi (per esempio `192.168.1.25`).
- Sul telefono, collegato alla stessa Wi-Fi, apri `http://192.168.1.25:3000`, sostituendo l'indirizzo d'esempio con quello del tuo PC.
- Accedi con la stessa password del server. Sia il computer sia il telefono vedranno gli stessi suoni, perché leggono la stessa raccolta sul server.

Se Windows chiede di consentire a Node.js l'accesso alla rete, consentilo solo sulle reti private fidate. Se il telefono non si connette, controlla che PC e telefono siano sulla stessa rete e che il firewall consenta la porta 3000. L'indirizzo locale funziona solo sulla rete di casa/locale e mentre il PC è acceso.

## Render: pubblicarlo online con archivio persistente

Per avere lo stesso sito anche fuori dalla Wi-Fi, serve un hosting pubblico che supporti un **disco persistente**. In questa cartella è incluso `render.yaml`, che prepara un servizio Render con `DATA_DIR=/var/data` e un disco persistente da 1 GB.

1. Crea un repository privato su GitHub e carica il contenuto di questa cartella (non includere `.env`, `data` o `node_modules`).
2. In Render scegli **New → Blueprint**, collega quel repository e applica `render.yaml`.
3. Durante la configurazione imposta una password privata nella variabile `APP_PASSWORD`. Non usare la password di esempio o una password che usi su altri siti.
4. Completa la creazione del servizio e apri l'URL HTTPS fornito da Render sul computer e sul telefono.
5. Accedi da ogni dispositivo con la stessa password. I file caricati sono salvati sul disco persistente del servizio.

La disponibilità e il costo di dischi persistenti e servizi web dipendono dal piano del provider; il livello gratuito di un hosting che cancella il filesystem al riavvio non è adatto a conservare in modo affidabile gli audio caricati. Non committare mai `.env` o file audio personali in un repository pubblico.

## Dove vengono salvati i dati

- In locale: `data/sounds.json` e `data/uploads/`.
- In hosting con il file `render.yaml`: `/var/data/sounds.json` e `/var/data/uploads/`.

Se il disco persistente viene eliminato o il server viene trasferito senza la cartella dati, i file caricati non possono essere recuperati da questo programma. Tieni una copia della cartella dati se gli audio sono importanti.

## Note sui link YouTube e TikTok

La soundboard salva l'indirizzo del video, l'ID e i due orari. Al tocco del pulsante mostra il player ufficiale e riproduce da `inizio` a `fine`. Per esempio, `0:42` fino a `0:48` riproduce il segmento tra 42 e 48 secondi. Il sito non crea un MP3 scaricato: il clip dipende dalla disponibilità, dai controlli e dalle restrizioni della piattaforma originale.

Alcuni collegamenti brevi TikTok possono non esporre l'ID del post. Se il server non riesce a risolverli, incolla il link completo del video, che normalmente contiene `/video/` seguito da un numero lungo.

## Sicurezza

La password protegge la gestione della raccolta e il server non espone API di modifica senza autenticazione. Pubblica il progetto solo su HTTPS, usa una password lunga e non condividerla oltre le persone di cui ti fidi. Per il server locale, la password iniziale di sviluppo è `instants-local-2026` solo se non hai creato il file `.env`; cambiala prima di qualsiasi pubblicazione online.
